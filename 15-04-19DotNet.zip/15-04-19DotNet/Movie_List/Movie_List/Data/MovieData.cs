﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Movie_List.Data;
using Movie_List.Models;

namespace Movie_List.Data
{
    public class MovieData
    {
        public static List<Information> GetData()
        {
            Information info = new Information
            {
                MovieId = 1,
                MovieName = "3 Idiots",
                ReleaseYear = "2010",
                Genre = "Comedy, Drama"

            };

            Information info2 = new Information
            {
                MovieId = 2,
                MovieName = "Taare Zameen Par",
                ReleaseYear = "2009",
                Genre = "Drama"
            };

            Information info3 = new Information
            {
                MovieId = 3,
                MovieName = "Aankhein",
                ReleaseYear = "2005",
                Genre = "Suspense, Drama"
            };

            Information info4 = new Information
            {
                MovieId = 4,
                MovieName = "Phir bhi dil hai Hindustaani",
                ReleaseYear = "2008",
                Genre = "Drama"
            };

            List<Information> data = new List<Information>();
            data.Add(info);
            data.Add(info2);
            data.Add(info3);
            data.Add(info4);
            return data;
        }

        public static Information GetMovie(int id)
        {
            return GetData().Where(x => x.MovieId == id).FirstOrDefault();
        }
    }
}
