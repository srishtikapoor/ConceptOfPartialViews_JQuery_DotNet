﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Movie_List.Data;
using Movie_List.Models;

namespace Movie_List.Controllers
{
    public class MovieController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult MovieList()
        {
            // SportsData obj = new SportsData();

            List<Information> ob = MovieData.GetData();


            return View(ob);
        }

        public IActionResult SearchById(int id)
        {
            var movie = MovieData.GetMovie(id);
            return PartialView("FilteredMoviePartial", movie);
        }
    }
}